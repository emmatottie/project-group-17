export class Collection {
	id: number;
	backdrop_path: string;
	name: string;
	poster_path: string;
}