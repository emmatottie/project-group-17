export class Language {
	iso_639_1: string;
	name: string;
}