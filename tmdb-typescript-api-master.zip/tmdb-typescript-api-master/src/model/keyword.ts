export class Keyword {
	id: number;
	name: string;
}