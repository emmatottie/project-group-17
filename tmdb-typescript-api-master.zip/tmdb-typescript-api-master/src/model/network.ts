export class Network {
	id: number;
	name: string;
}