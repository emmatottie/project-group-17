export class Country {
	iso_3166_1: string;
	name: string;
}