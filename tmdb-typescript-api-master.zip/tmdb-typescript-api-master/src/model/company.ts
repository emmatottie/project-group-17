export class Company {
	id: number;
	logo_path: string;
	name: string;
}