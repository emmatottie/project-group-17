export class Season {
	id: number;
	episode_count: number;
	poster_path: string;
	season_number: number;
	air_date: Date;
}