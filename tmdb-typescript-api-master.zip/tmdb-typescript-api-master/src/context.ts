export class Context {
	apiKey: string;
	language: string = 'en';
	baseUrl = 'https://api.themoviedb.org/3';
}